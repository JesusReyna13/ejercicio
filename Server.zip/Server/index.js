const express = require("express");
const app = express();
const mysql = require("mysql");
const cors = require("cors");


//Lado servidor.


app.use(cors());
app.use(express.json());


const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "ejercicio"
});

//Retorna los cobros pendientes y calcula el pago.
app.get("/pending-loans", (req, res)=>{
    db.query('SELECT loans.Client, sucursales.Name, loans.ID, loans.Amount, sucursales.IVA, loans.Amount + ((loans.Amount/100)* sucursales.IVA) as amount FROM loans INNER JOIN sucursales ON loans.IdSucursal = sucursales.ID WHERE Status = "Pendiente"',
        (error,result)=>{
        if(error){
            console.log(error);
        }else{
            res.send(result);
        }
    })
});

//Retorna la informacion de la tabla cuentas de debito activas considerando el iva%
app.get("/cobroPagos", (req, res)=>{
    db.query('SELECT loans.Client, sucursales.Name, loans.ID, loans.Amount, sucursales.IVA , (SUM(loans.Amount + ((loans.Amount/100)* sucursales.IVA)) ) as DeudaTotal, IF(accounts.Status="Activa", accounts.Amount - SUM(loans.Amount + ((loans.Amount/100)* sucursales.IVA)), SUM(loans.Amount + ((loans.Amount/100)* sucursales.IVA)) ) AS amount FROM ((`loans` INNER JOIN sucursales ON loans.IdSucursal = sucursales.ID) INNER JOIN accounts ON loans.Client = accounts.Client) WHERE loans.Status = "Pendiente" GROUP BY loans.Client ORDER BY loans.Client; ',(error, result)=>{
        if(error){
            console.log(error);
        }else{
            res.send(result);
        }
    })
})

//Actualiza la tabla accounts de acuerdo a cobroPagos.
app.post("/update",(req,res)=>{
    db.query('UPDATE accounts SET Amount ='+ Amount + 'WHERE `accounts`.`Client` ='+ Client + ';',(error, result)=>{
        if(error){
            console.log(error);
        }else{
            res.send("Exito");
        }
    })
    
})


app.listen(3001, ()=>{
    console.log("Existo puerto 3001 escuchando")
})
