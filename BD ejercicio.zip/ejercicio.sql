-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 07-11-2024 a las 11:36:58
-- Versión del servidor: 10.4.21-MariaDB
-- Versión de PHP: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `ejercicio`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `accounts`
--

CREATE TABLE `accounts` (
  `Client` varchar(50) COLLATE utf8mb4_spanish2_ci NOT NULL,
  `Amount` float NOT NULL,
  `Status` varchar(50) COLLATE utf8mb4_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

--
-- Volcado de datos para la tabla `accounts`
--

INSERT INTO `accounts` (`Client`, `Amount`, `Status`) VALUES
('78be3a77-698d-43ef-b113-a598eb1fb791 ', 0, 'Cancelada'),
('8482bcae-0b2b-45bb-9012-59ec93978265', 3728.51, 'Bloqueada'),
('911ac37c-5990-4bf8-8cf0-b51f21c8ecbe', 15375.3, 'Activa'),
('cee008ca-c715-456b-96c6-74ff9bd22dd3 ', 235.28, 'Activa');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `loans`
--

CREATE TABLE `loans` (
  `Client` varchar(50) COLLATE utf8mb4_spanish2_ci NOT NULL,
  `ID` int(20) NOT NULL,
  `Date_Loan` date NOT NULL,
  `Amount` float NOT NULL,
  `Status` varchar(50) COLLATE utf8mb4_spanish2_ci NOT NULL,
  `IdSucursal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

--
-- Volcado de datos para la tabla `loans`
--

INSERT INTO `loans` (`Client`, `ID`, `Date_Loan`, `Amount`, `Status`, `IdSucursal`) VALUES
('911ac37c-5990-4bf8-8cf0-b51f21c8ecbe', 1, '2021-01-15', 37500, 'Pendiente', 3),
('911ac37c-5990-4bf8-8cf0-b51f21c8ecbe', 2, '2021-01-24', 725.18, 'Pendiente', 3),
('911ac37c-5990-4bf8-8cf0-b51f21c8ecbe', 3, '2021-02-05', 1578.22, 'Pendiente', 3),
('911ac37c-5990-4bf8-8cf0-b51f21c8ecbe', 4, '2021-02-09', 380, 'Pendiente', 3),
('8482bcae-0b2b-45bb-9012-59ec93978265', 1, '2021-01-12', 2175.25, 'Pagado', 2),
('8482bcae-0b2b-45bb-9012-59ec93978265', 2, '2021-01-18', 499.99, 'Pagado', 2),
('8482bcae-0b2b-45bb-9012-59ec93978265', 3, '2021-01-29', 5725.18, 'Pendiente', 2),
('8482bcae-0b2b-45bb-9012-59ec93978265', 4, '2021-02-12', 876.13, 'Pendiente', 2),
('78be3a77-698d-43ef-b113-a598eb1fb791 ', 1, '2021-02-09', 545.55, 'Pendiente', 1),
('cee008ca-c715-456b-96c6-74ff9bd22dd3 ', 1, '2020-12-31', 15220, 'Pagado', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sucursales`
--

CREATE TABLE `sucursales` (
  `ID` int(11) NOT NULL,
  `Name` varchar(50) COLLATE utf8mb4_spanish2_ci NOT NULL,
  `IVA` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

--
-- Volcado de datos para la tabla `sucursales`
--

INSERT INTO `sucursales` (`ID`, `Name`, `IVA`) VALUES
(1, 'Tijuana', 8),
(2, 'Nuevo Leon', 16),
(3, 'Tamaulipas', 10);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`Client`);

--
-- Indices de la tabla `loans`
--
ALTER TABLE `loans`
  ADD KEY `IdSucursal` (`IdSucursal`),
  ADD KEY `Client` (`Client`);

--
-- Indices de la tabla `sucursales`
--
ALTER TABLE `sucursales`
  ADD PRIMARY KEY (`ID`);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `loans`
--
ALTER TABLE `loans`
  ADD CONSTRAINT `loans_ibfk_1` FOREIGN KEY (`IdSucursal`) REFERENCES `sucursales` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `loans_ibfk_2` FOREIGN KEY (`Client`) REFERENCES `accounts` (`Client`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
